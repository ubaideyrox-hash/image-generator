#!/usr/bin/env bash

# make opnvg
cd /home/pi/piSignagePro/tools/openvg_display
chmod +x make.sh
./make.sh

