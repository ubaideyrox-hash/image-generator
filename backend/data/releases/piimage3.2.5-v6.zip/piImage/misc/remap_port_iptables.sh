#!/bin/bash

# This script allows webUI to be used in port 80 also, to add it to startup,
# copy this script to /etc/init.d directory:
# sudo cp /home/pi/piSignagePro/misc/remap_port_iptables.sh /etc/init.d
# and execute the following command and reboot:
# sudo update-rc.d remap_port_iptables.sh defaults

### BEGIN INIT INFO
# Provides:          remap_port_iptables
# Required-Start:    $local_fs $network
# Required-Stop:     $local_fs
# Default-Start:     2 3 4 5
# Default-Stop:      0 1 6
# Short-Description: remap_port_iptables
# Description:       Remaps port 80 to 8000
### END INIT INFO


# ************ Forwards even incoming port 80 traffic from server to 8000  - does not work ********

#if ! sudo iptables -t nat -L -n -v | grep -q -E "REDIRECT.+dpt:80.+ports[ |\t]+8000"; then
#    sudo iptables -t nat -A PREROUTING -p tcp --dport 80 -j REDIRECT --to-port 8000
#fi
