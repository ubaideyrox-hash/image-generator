'use strict';

// console.log(process.argv[2]);
// console.log(process.argv[3]);

var value = require(process.argv[2]);
var fields = process.argv[3].split('.');      //filed.subfield

for (var i = 0; i < fields.length; i++) {
    value = value[fields[i]];
}

if (!(value == null || value == undefined))
    console.log(value);