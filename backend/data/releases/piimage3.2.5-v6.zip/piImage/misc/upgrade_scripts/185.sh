#!/usr/bin/env bash
# Make all  wheezy release to refer lxde-rc from wheezy/lxde-rc.xml

CHECK_JESSIE=`cat /etc/*-release | grep "jessie"`

if [  -z "$CHECK_JESSIE" ]
then
	echo " Wheezy image -  Change LXDE symlink "
	rm -rf /home/pi/.config/openbox/lxde-rc.xml
	ln -s /home/pi/piSignagePro/misc/wheezy/lxde-rc.xml /home/pi/.config/openbox/lxde-rc.xml
fi

CHROME_PRESENT=`which chromium-browser`
if grep -q "jessie" /etc/*-release ;
then
    # jessie Image
	if [ ! -z "$CHROME_PRESENT" ];then
		echo "Change lightdm file "
    	sudo rm -rf /etc/lightdm/lightdm.conf
    	sudo cp /home/pi/piSignagePro/misc/jessie/lightdm.conf /etc/lightdm/lightdm.conf
	fi

fi

