#!/bin/bash

# add sleep line to start.sh to stop restart
LINEPRESENT=`grep "sleep" /home/pi/start.sh `
if [ -z "$LINEPRESENT" ];then
	echo "add line to start.sh"
	echo "sleep infinity" >> /home/pi/start.sh
fi

#install screenshot app if excutable missing
echo " Screenshot modification "
EXECUTABLE="/home/pi/piSignagePro/tools/screenshot/screenshot"

if [ ! -f "$EXECUTABLE" ];then
	echo "screen shot excutable not found, Install New"
	cd /home/pi/piSignagePro/tools/screenshot
	sudo rm -rf /usr/local/bin/screenshot
	chmod +x make.sh
	./make.sh
else
	echo "executable file present"
fi

# make pngview
echo "image view"
cd /home/pi/piSignagePro/tools/pngview
chmod +x make.sh
./make.sh
