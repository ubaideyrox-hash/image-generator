#!/usr/bin/env bash

INTERFACE_FILE="/etc/network/interfaces"
LINE_PRESENT=`cat ${INTERFACE_FILE} | grep "wireless-power off"`

if [  -z "$LINE_PRESENT" ]
then
	echo "Adding wifi power management option"
	sudo sed -i '/wpa-roam \/etc\/wpa_supplicant\/wpa_supplicant.conf/ a\wireless-power off' $INTERFACE_FILE
fi

if grep -q "jessie" /etc/*-release ;
then
    sudo apt-get -y update
    
    sudo apt-get -y install hostapd dnsmasq

    if grep -q "denyinterfaces wlan0" /etc/dhcpcd.conf; then
        echo "Line present "
    else
        echo "#denyinterfaces wlan0 " | sudo tee -a /etc/dhcpcd.conf
    fi

    if [ -f /etc/hostapd/hostapd.conf ];then
        sudo rm -rf /etc/hostapd/hostapd.conf
    fi

    sudo cp /home/pi/piSignagePro/misc/hostapd.conf /etc/hostapd/
    sudo chmod 755 /etc/hostapd/hostapd.conf
    CPUID=$(cat /proc/cpuinfo  |grep "Serial" | cut -f 2 -d : | tr -d " ")
	ACCESS_POINT_NAME=$(echo "${CPUID: -4}")
	sudo sed -i 's/^ssid=.*/ssid=piplayer_'$ACCESS_POINT_NAME'/' /etc/hostapd/hostapd.conf

    sudo sed -i 's|.*#DAEMON_CONF=""*.|DAEMON_CONF="/etc/hostapd/hostapd.conf"|' /etc/default/hostapd

    sudo mv /etc/dnsmasq.conf /etc/dnsmasq.conf.orig
    sudo cp /home/pi/piSignagePro/misc/dnsmasq.conf /etc/dnsmasq.conf
    sudo chmod 755 /etc/dnsmasq.conf

    sudo systemctl stop hostapd.service
    sudo systemctl stop dnsmasq.service

    sudo systemctl disable hostapd.service
    sudo systemctl disable dnsmasq.service
    sudo systemctl daemon-reload
fi
