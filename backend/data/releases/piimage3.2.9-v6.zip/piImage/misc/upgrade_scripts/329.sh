#!/usr/bin/env bash

sudo apt update
sudo apt -y full-upgrade 
sudo yt-dlp -U


