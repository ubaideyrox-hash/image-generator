#!/usr/bin/env bash

# make opnvg
echo "OpenVG ticker length"
cd /home/pi/piSignagePro/tools/openvg_display
chmod +x make.sh
./make.sh

# make screenshot
echo "Screenshot portrait"
cd /home/pi/piSignagePro/tools/screenshot
chmod +x make.sh
./make.sh


echo "Youtube DL"
sudo pip install --upgrade youtube-dl

