#!/usr/bin/env bash

#a fork of youtube-dl called yt-dlp, loads faster, appears to be higher quality and for the first time doesn’t skip at all
sudo curl -L https://github.com/yt-dlp/yt-dlp/releases/latest/download/yt-dlp -o /usr/local/bin/yt-dlp
sudo chmod a+rx /usr/local/bin/yt-dlp

