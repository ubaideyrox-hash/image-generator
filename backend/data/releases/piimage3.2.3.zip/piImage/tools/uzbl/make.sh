#!/usr/bin/env bash
# script to install uzbl-0.9 version
# command line usage :    
#						. make.sh  
#						. make.sh <commit-number>
#					
#	EX:  . make.sh 35db169a31c8c02b1846828c60ced8454b819a9c


update_uzbl(){
	echo "UZBL code base will be moved to commit : $1"

	cd /home/pi/uzbl
	sudo make uninstall
	sudo make clean

	# udpate code base and go to v0.9.0 commit 
	git pull origin master
	git fetch --tags
	git checkout $1
	make
	sudo make install

	# remove old symlink
	sudo rm -rf /usr/local/bin/uzbl
	sudo ln -s /usr/local/bin/uzbl-browser /usr/local/bin/uzbl
}

install_uzbl_git(){
	echo "uzbl repo not found, So installing uzbl ... "
	rm -rf /home/pi/uzbl
	cd /home/pi/
	git clone git://github.com/uzbl/uzbl.git
	cd uzbl
    git fetch --tags
	git checkout $1
	make
	sudo make install

    sudo rm -rf /usr/local/bin/uzbl
	sudo ln -s /usr/local/bin/uzbl-browser /usr/local/bin/uzbl
}

if [ -z $1 ];then
	COMMIT="tags/v0.9.0"
else
	COMMIT=$1
fi

if [ -d "/home/pi/uzbl" ];then
	update_uzbl $COMMIT
#else
#	sudo apt-get -y remove uzbl
#	install_uzbl_git $COMMIT
fi

