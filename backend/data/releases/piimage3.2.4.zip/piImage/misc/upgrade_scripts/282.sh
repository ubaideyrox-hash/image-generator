#!/usr/bin/env bash


if grep -q "buster" /etc/*-release; then
    echo "Buster release"

    #for 2 display support
    #https://github.com/raspberrypi-ui/gldriver-test/blob/master/usr/lib/systemd/scripts/gldriver_test.sh
    sudo cp /home/pi/piSignagePro/misc/upgrade_scripts/99-fbturbo.conf /usr/share/X11/xorg.conf.d/
fi

