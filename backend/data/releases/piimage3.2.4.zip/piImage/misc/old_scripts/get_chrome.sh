#!/bin/bash
sudo pkill node 
sudo pkill omx
sudo pkill uzbl

sudo apt-get -y update
echo "y\n Y\n" | sudo apt-get -y dist-upgrade
# echo "\n \n" | sudo apt-get install -y r^C-chromium-mods
sudo apt-get install -y rpi-chromium-mods
sudo apt-get install -y python-sense-emu python3-sense-emu
sudo apt-get install -y python-sense-emu-doc realvnc-vnc-viewer
sudo sed -e 's/^#xserver-command=X$/xserver-command=X -nocursor -s 0 dpms/g' -i /etc/lightdm/lightdm.conf
chromium-browser http://pisignage.com &
sleep 10
sudo reboot