#!/usr/bin/env bash

sudo apt-get -y install evince
sudo sed -i 's/^Exec=/# &/' /usr/share/thumbnailers/evince.thumbnailer
