#!/usr/bin/env bash
cd /home/pi/piSignagePro/tools/pngview2
make
sudo rm -f /usr/local/bin/pngview2
sudo cp /home/pi/piSignagePro/tools/pngview2/pngview2 /usr/local/bin/pngview2
sudo chmod +x /usr/local/bin/pngview2
