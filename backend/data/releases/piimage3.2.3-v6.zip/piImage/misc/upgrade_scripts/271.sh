#!/bin/bash

# make pngview
echo "image view"
cd /home/pi/piSignagePro/tools/pngview
chmod +x make.sh
./make.sh

# make new pngview
echo "pngview2"
cd /home/pi/piSignagePro/tools/pngview2
chmod +x make.sh
./make.sh


