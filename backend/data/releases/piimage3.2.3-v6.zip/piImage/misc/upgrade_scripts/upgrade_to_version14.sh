#!/usr/bin/env bash

if grep -q "buster" /etc/*-release; then
  echo "Buster release"
  sudo pkill -f node #kill all node processes
  sudo npm update -g npm
  wget https://nodejs.org/dist/v14.12.0/node-v14.12.0-linux-armv7l.tar.xz
  tar xvf node-v14.12.0-linux-armv7l.tar.xz
  cd node-v14.12.0-linux-armv7l
  sudo cp -R bin/* /usr/bin/
  sudo cp -R lib/* /usr/lib/
  sudo apt-get update

  cd /home/pi/piSignagePro
  PI_SERVER=$(cat /home/pi/piSignagePro/package.json | grep config | tr -d '[,"]' | awk '{print $2}')
  if [ -z "$PI_SERVER" ]; then
    PI_SERVER="pisignage.com"
  fi
  wget $PI_SERVER/releases/package-v14.json  -O package.json

  sed -i 's/.*"config_server".*/    "config_server": \"'$PI_SERVER'",/g' package.json
  sed -i 's/.*"media_server".*/    "media_server":   \"'$PI_SERVER'",/g' package.json

  rm -rf node_modules
  npm install

  node -v
  npm -v
  cat package.json

fi
