#!/usr/bin/env bash

mkdir /home/pi/pisignage-data
echo "#!/usr/bin/env bash" > /home/pi/pisignage-data/upgrade.sh

cd /home/pi/
wget https://s3.amazonaws.com/pisignage/assets/pisignage/update.png

echo "Youtube DL"
sudo pip install --upgrade youtube-dl

