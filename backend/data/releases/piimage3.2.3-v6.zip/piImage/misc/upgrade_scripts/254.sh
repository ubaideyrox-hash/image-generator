#!/usr/bin/env bash

if grep -q "buster" /etc/*-release; then
    echo "Buster release"
    if [ $(getconf _NPROCESSORS_ONLN) -eq 4 ]; then
        echo "Installing MPV in Buster"
        wget https://s3.amazonaws.com/pisignage/assets/binaries/mpv_0.29.1_armhf_buster.deb
        sudo apt-get update
        sudo apt install -y ./mpv_*.deb
        sudo apt-get update
        sudo apt install -f
        sudo apt install -y ./mpv_*.deb           #try again if failed before
    fi
fi
