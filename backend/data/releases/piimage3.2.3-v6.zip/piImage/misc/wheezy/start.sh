#!/bin/bash
#midori -e Fullscreen -a www.bbc.co.uk &
#uzbl www.yahoo.com &
unclutter -idle 5 &
cd /home/pi/piSignagePro
#/opt/node/bin/node server.js
#forever start -l /var/log/forever.log -o /var/log/forever-out.log -e/var/log/forever-err.log server.js

#rpi-wiggle should be RUN ONLY ONCE
echo "CONF_SWAPSIZE=500" > /home/pi/dphys-swapfile
sudo cp /etc/dphys-swapfile /etc/dphys-swapfile.bak
sudo mv /home/pi/dphys-swapfile /etc/dphys-swapfile
sudo raspi-config --expand-rootfs
sed -i '9,15d' /home/pi/start.sh
sudo reboot

#forever start --append -l ~/forever.log pi-server.js
. /home/pi/.bash_profile
export WEBKIT_DISABLE_TBS=1
node pi-monitor.js
sleep 10 
sudo kill $(pidof python omx.py)
sudo pkill omxplayer
sleep infinity