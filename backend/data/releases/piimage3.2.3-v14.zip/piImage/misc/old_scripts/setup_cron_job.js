'use strict';

var rebootTime = '';
var cmd, h, m;

if (process.argv.length < 3) {
    console.log('Usage:', process.argv[2], '<reboot-enable> <reboot-time>');
    exit(1);
}

var enable = process.argv[2];
if (process.argv.length < 4 && enable === 'true') {
    console.log('Usage:', process.argv[2], '<reboot-enable> <reboot-time>');
    exit(1);
}
if (enable === 'true') {
    rebootTime = (new Date(process.argv[3]));
    rebootTime.setTime(rebootTime.getTime() +
                       rebootTime.getTimezoneOffset() * 60 * 1000);
    h= rebootTime.getHours();
    m = rebootTime.getMinutes();

    cmd = 'echo "' + m + ' ' + h + ' * * * /sbin/reboot" | sudo crontab -';
} else {
    cmd = 'sudo crontab -r';
}
console.log(cmd);
