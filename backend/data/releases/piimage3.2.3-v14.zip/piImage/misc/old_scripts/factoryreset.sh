#!/bin/bash
HOSTNAME=$(id -un)

#change dispaly settings
echo "Changing Dispaly Settings"
sudo sed 's/.*disable_overscan.*/disable_overscan=1/' -i /boot/config.txt
sudo sed 's/.*hdmi_force_hotplug.*/hdmi_force_hotplug=1/' -i /boot/config.txt
sudo sed 's/.*hdmi_group.*/hdmi_group=1/' -i /boot/config.txt
sudo sed 's/.*hdmi_mode.*/hdmi_mode=4/' -i /boot/config.txt
sudo sed 's/.*hdmi_drive.*/hdmi_drive=2/' -i /boot/config.txt

sudo sed -i -e 's/.*overscan_left.*/overscan_left=40/' -e 's/.*overscan_right.*/overscan_right=40/' -e 's/.*overscan_top.*/overscan_top=20/' -e 's/.*overscan_bottom.*/overscan_bottom=20/' -e 's/.*framebuffer_width.*/framebuffer_width=1280/' -e 's/.*framebuffer_height.*/framebuffer_height=720/'  /boot/config.txt

sudo sed -i 's/.*XKBLAYOUT=.*/XKBLAYOUT="us"/' /etc/default/keyboard

sudo sed -i 's/.*display_rotate.*/display_rotate=0/' /boot/config.txt

# change network interface
echo "Changing Network Interface"
sudo rm -rf /etc/network/interface
sudo cp /home/pi/piSignagePro/misc/interfaces /etc/network/interfaces


# change server name
# echo "Changing Server Name"
# sed  -i 's/.*config_serv.*/    "config_server": "pisignage.com",/' /home/pi/piSignagePro/package.json
# sed -i 's/.*media_serv.*/    "media_server": "pisignage.com",/' /home/pi/piSignagePro/package.json

# remove settings and config
echo "Remove Identity File"
sudo rm -rf  /home/pi/piSignagePro/config/_settings.json
sudo rm -rf  /home/pi/piSignagePro/config/_config.json

# change ht passwd file
echo 'pi:$apr1$G4yYdggH$aqJwlrg6yXYERl4DCZ2DT1' > /home/pi/piSignagePro/htpasswd

# change hostname , do not use any command after this step
echo "Change HOSTNAME"
if [ $HOSTNAME == "raspberrypi" ]
then
	echo "NO change to user"
else
	echo "change user"
	HOSTNAME="raspberrypi"
	sudo /bin/bash /home/pi/piSignagePro/misc/change-hostname.sh $HOSTNAME
fi

#change DNS server to default
sudo /bin/bash /home/pi/piSignagePro/misc/networkchange.sh "8.8.4.4" "8.8.8.8"