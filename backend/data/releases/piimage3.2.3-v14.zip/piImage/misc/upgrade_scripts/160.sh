#!/usr/bin/env bash
# remove network-config file and replace with symlink
cd /home/pi/piSignagePro/misc
sudo rm -rf /usr/bin/network-config
sudo ln -s /home/pi/piSignagePro/misc/network-config /usr/bin/network-config
sudo chmod +x /home/pi/piSignagePro/misc/network-config
sudo chmod +x  /usr/bin/network-config

# Youtube updated its info method
sudo sed -i 's/.*http.get(API_VIDEO_INFO, params=params.*/\tres = http.get(API_VIDEO_INFO, params=params , headers=HLS_HEADERS)/' /usr/local/lib/python2.7/dist-packages/livestreamer/plugins/youtube.py

# install gcc tools for missing devices
sudo apt-get -y install build-essential

# make screenshot
cd /home/pi/piSignagePro/tools/screenshot
chmod +x make.sh
./make.sh

#update uzbl
cd /home/pi/piSignagePro/tools/uzbl
chmod +x make.sh
./make.sh

echo "gtk css"
if [ -d "/home/pi/.config/gtk-3.0" ];then
    sudo rm -rf /home/pi/.config/gtk-3.0/gtk.css
    sudo cp /home/pi/piSignagePro/misc/gtk.css /home/pi/.config/gtk-3.0/
    sudo chmod +x /home/pi/.config/gtk-3.0/gtk.css
fi