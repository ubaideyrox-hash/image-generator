#!/bin/bash


echo "release specific commands 0.8.9"

#overscan values
sudo sed 's/.*disable_overscan.*/disable_overscan=1/' -i /boot/config.txt
sudo sed -i '$a\overscan_scale=1' /boot/config.txt
sudo sed -i -e 's/.*overscan_left.*/overscan_left=40/' -e 's/.*overscan_right.*/overscan_right=40/' -e 's/.*overscan_top.*/overscan_top=20/' -e 's/.*overscan_bottom.*/overscan_bottom=20/' -e 's/.*framebuffer_width.*/framebuffer_width=1280/' -e 's/.*framebuffer_height.*/framebuffer_height=720/'  /boot/config.txt

# fsck issue
sudo mv /boot/cmdline.txt /boot/cmdline.txt.bak
sudo cp ~/piSignagePro/misc/wheezy/cmdline.txt /boot/cmdline.txt
sudo cp ~/piSignagePro/misc/wheezy/pifstab /etc/fstab
sudo sed -i 's/.*#FSCKFIX.*/FSCKFIX=yes/' /etc/default/rcS

# include rc.local to force fsck
sudo mv /etc/rc.local /etc/rc.local.old
sudo mv /home/pi/piSignagePro/misc/wheezy/rc.local /etc/
sudo chmod 755 /etc/rc.local

#*******************************************************************
# run asplashscreen process with delay and rename file
#*******************************************************************
sudo mv /etc/init.d/asplashscreen /etc/init.d/newwelcome
sudo chmod a+x /etc/init.d/newwelcome
sudo insserv /etc/init.d/newwelcome

# creation of eth0:1 sub interface  using sed
#if grep -q "auto eth0:1" "/etc/network/interfaces"; then
#  echo "eth0:1 found"
#else
#  echo "eth0:1 not found"
#  sudo sed -i '/iface lo inet loopback/ a\ \nauto eth0:1\niface eth0:1 inet static\n      address 192.168.167.166\n      netmask 255.255.255.0\n      gateway 192.168.167.1\n' /etc/network/interfaces
#fi

# needed by nwdiag for pre 1.1.0 platform images
sudo apt-get -y install  host ethtool nmap

#create a logs dir
mkdir -p /home/pi/logs
chmod -R 777 /home/pi/logs

#add bash_profile execution inside start.sh
if grep -q "bash_profile" "/home/pi/start.sh"
then
    echo "bash_profile already added"
else
    echo "adding .bash_profile"
    sudo sed -i '/node pi-monitor.js/ i\ \n. /home/pi/.bash_profile\n' /home/pi/start.sh
fi


